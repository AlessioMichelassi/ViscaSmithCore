from setuptools import setup, find_packages

setup(
    name="viscSmithCore",
    version="0.4.0",
    author="Il Tuo Nome",
    author_email="alessio.michelassi@gmail.com",
    description="Una libreria per controllare telecamere VISCA tramite UDP",
    long_description=open("readMe.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/AlessioMichelassi/ViscaSmithCore",
    packages=find_packages(include=["visca_control", "visca_control.*"]),
    include_package_data=True,  # Includi file non Python (es. JSON)
    install_requires=["PyQt6", "PyQt6-sip", "PyQt6-Qt6", "PyQt6-Qt6-sip", "PyQt6-Designer"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)