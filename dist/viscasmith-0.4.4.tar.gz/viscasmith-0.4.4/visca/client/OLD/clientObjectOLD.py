from PyQt6.QtCore import QObject, pyqtSignal, QTimer
from PyQt6.QtNetwork import QUdpSocket, QHostAddress
from PyQt6.QtWidgets import QApplication

from visca.cameraObject import CameraObject
from visca.dataStucture.messagePacker import MessagePacker
from visca.dictionary.enumerations import ExposureModeEnum

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 52381
VISCA_TERMINATOR = b'\xff'
CAMERA_ID = b'\x81'

class ClientObject(QObject):

    server_address: QHostAddress
    server_port: int

    info_SIGNAL = pyqtSignal(str, name="message_SIGNAL")
    error_SIGNAL = pyqtSignal(str, name="error_SIGNAL")
    serverMessage = pyqtSignal(str, name="serverMessage")
    def __init__(self, parent=None):
        super().__init__(parent)
        self.socket = QUdpSocket(self)
        self.messagePacker = MessagePacker()

    def connect(self, host: str, port: int):
        """
        Connette il client al server Visca over IP.
        :param host: 127.0.0.1
        :param port: 52381
        :return:
        """
        self.server_address = QHostAddress(host)
        self.server_port = port
        # Connect the readyRead signal to handle incoming responses
        self.socket.readyRead.connect(self.handleReadyRead)
        self.sendHandshake()

    def handleReadyRead(self):
        while self.socket.hasPendingDatagrams():
            datagram, host, port = self.socket.readDatagram(self.socket.pendingDatagramSize())
            self.info_SIGNAL.emit(f"Received Datagram from {host.toString()}:{port}: {datagram.hex().upper()}")
            self.onMessageReceived(datagram)

    def sendHandshake(self):
        """
        Invia il messaggio di handshake al server.
        """
        handshake_message = b'\x02\x00\x00\x01\x00\x00\x00\x01\x01'
        self.socket.writeDatagram(handshake_message, self.server_address, self.server_port)
        self.info_SIGNAL.emit(f"Sent Handshake:\n\t{handshake_message.hex().upper()}\n\t{handshake_message}")

    def sendIFClear(self):
        """
        Invia il messaggio IF_Clear al server.
        """
        if_clear_message = b'\x01\x00\x00\x05\x00\x00\x00\x02' + CAMERA_ID + b'\x01\x00\x01' + VISCA_TERMINATOR
        print(if_clear_message)
        self.socket.writeDatagram(if_clear_message, self.server_address, self.server_port)
        self.info_SIGNAL.emit(f"Sent IF_Clear:\n\t{if_clear_message.hex().upper()}\n\t{if_clear_message}")

    def sendMessage(self, cmd: str):
        """
        Invia un messaggio al server.
        """
        message = self.messagePacker.build_command(cmd)

        try:
            print(f"Sending Message: {message}")
            self.socket.writeDatagram(message, self.server_address, self.server_port)
            self.info_SIGNAL.emit(f"Sent Message:\n\t{message.hex().upper()}\n\t{message}")
        except Exception as e:
            self.error_SIGNAL.emit(f"Error sending message: {e}")

    def onMessageReceived(self, message):
        """
        Riceve un messaggio dal server e lo emette.
        """
        self.serverMessage.emit(f"Received Message:\n\t{message.hex().upper()}\n\t{message}")
        self.parseMessage(message)

    def parseMessage(self, data):
        if self.isHandShake(data):
            print("Handshake detected.")
        elif self.isIFClear(data):
            print("IF_Clear detected.")
            self.sendIFClear()
        else:

            header, payload, terminator = self.unpackMessage(data)
            preamble = payload[1:2]  # Identifica il tipo di comando
            camera_id = payload[:1]  # Identifica l'ID della camera
            command_payload = payload[2:]  # Rimuove ID camera e preambolo

            print(f"Camera ID: {camera_id.hex()}")
            print(f"Preambolo: {preamble.hex()}")
            print(f"Comando Payload: {command_payload.hex()}")

    @staticmethod
    def unpackMessage(data: bytes):
        """
        Estrae header, payload e terminatore dal messaggio.
        """
        header = data[:8]
        payload = data[8:-1]
        terminator = data[-1:]
        return header, payload, terminator

    def isHandShake(self, data):
        """
        Verifica se il messaggio è un handshake.
        """
        return data == b'\x02\x00\x00\x01\x00\x00\x00\x01\x01'

    def isIFClear(self, data):
        """
        Verifica se il messaggio è un IF_Clear.
        """
        return data == b'\x01\x00\x00\x05\x00\x00\x00\x02\x81\x01\x00\x01\xff'




if __name__ == "__main__":
    app = QApplication([])
    client = ClientObject()
    client.connect(SERVER_HOST, SERVER_PORT)
    camera = CameraObject()

    # Collegamento ai segnali per debug
    client.error_SIGNAL.connect(print)
    client.info_SIGNAL.connect(print)
    client.serverMessage.connect(print)

    # Messaggi da inviare
    exposure_message = camera.exposure.setExposureMode(ExposureModeEnum.MANUAL)
    QTimer.singleShot(1000, lambda: client.sendMessage(exposure_message))

    QTimer.singleShot(2000, lambda: client.sendMessage(camera.exposure.getExposureMode()))
    app.exec()


